import it.utils.shape.Circle;
import it.utils.shape.Triangle;

public class TestShape {
    public static void main(String[] args){
        Circle circle=new Circle();
        circle.inputParameters();
        System.out.println("Circle raduis: "+circle.getRadius());
        System.out.println("Circle area: "+circle.getArea());
        System.out.println("Circle circumference: "+circle.getCircumference());
        Triangle triangle=new Triangle();
        triangle.inputParameters();
        System.out.println("Triangle base: "+triangle.getBase()+" height:"+triangle.getHeight());
        System.out.println("Triangle height: "+triangle.getArea());
    }
}

package com.example.utils;

public class StringHelper {
    public static String reverse(String text) {
        StringBuilder str=new StringBuilder();
        String recStr=str.reverse().toString();
        //return recStr;
        return new StringBuilder(text).reverse().toString();

    }
}

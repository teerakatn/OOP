import com.example.utils.StringHelper;

public class TestPackage {
    public static void main(String[] args) {
        StringHelper myStr=new StringHelper();
    }
}

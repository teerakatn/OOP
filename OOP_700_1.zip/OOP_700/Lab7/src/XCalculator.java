public interface XCalculator {
    public double add2Number(double a, double b);
    public double sub2Number(double a, double b);
}
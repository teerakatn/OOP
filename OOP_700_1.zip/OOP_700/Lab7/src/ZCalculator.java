public interface ZCalculator extends XCalculator, YCalculator {
    public double power(double base, int powerNo);
}

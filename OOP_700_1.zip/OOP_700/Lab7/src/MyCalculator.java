public class MyCalculator implements XCalculator {
    @Override
    public double add2Number(double x, double y) {
        return x + y;
    }
    @Override
    public double sub2Number(double a, double b) {
        return a - b;
    }
}

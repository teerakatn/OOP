public interface YCalculator {
    public double multiply2Number(double a, double b);
    public double divide2Number(double a, double b);
}

package it.store.utils.receipt;

public interface Receipt {
    public void printReceipt();
}

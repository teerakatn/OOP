public class TestAnimal {
    public static void main(String[] args) {
        Dog buddy=new Dog("Budy");
        buddy.sound();

        Cat mycat=new Cat("mycat");
        mycat.sound();

        Brid bd=new Brid("bd");
        bd.sound();

        Animal A1=new Animal("A1");
        A1.sound();
    }
}

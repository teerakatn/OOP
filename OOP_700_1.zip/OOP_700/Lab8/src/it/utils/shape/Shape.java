package it.utils.shape;

public interface Shape {
    public void inputParameters();
    public double getArea();
}
